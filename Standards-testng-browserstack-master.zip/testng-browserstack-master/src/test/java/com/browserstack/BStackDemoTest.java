package com.browserstack;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

public class BStackDemoTest extends SeleniumTest {
    @Test(priority = 0)
    public void launchWebsite() throws InterruptedException {
        driver.get("https://store.standards.org.au/reader/as-3633-1989?preview=1");
        
        // Take an initial screenshot
        PercySDK.screenshot(driver, "name");
        
        // Create a JavascriptExecutor instance
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Scroll the specific element
        js.executeScript("document.getElementById('ereader-content').scrollBy(0, 20000);");

        // Optionally wait to see the scroll effect, if necessary
        Thread.sleep(2000); // Adjust this as needed

        // Take a screenshot after scrolling
        PercySDK.screenshot(driver, "afterscroll");
    }
}